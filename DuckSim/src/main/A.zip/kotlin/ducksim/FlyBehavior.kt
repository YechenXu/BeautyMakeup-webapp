package ducksim

interface FlyBehavior {
    val state: State
}