package ducksim

interface Observer {
    fun update()
}