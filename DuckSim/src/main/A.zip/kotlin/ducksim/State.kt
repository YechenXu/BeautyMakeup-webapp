package ducksim

enum class State {
    SWIMMING, FLYING, QUACKING, WELCOMING
}
