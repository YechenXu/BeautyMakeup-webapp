package ducksim

class Goose {
    open val honkText:String = "Honk"
    open val name = "Goose"
}