package ducksim

class QuackSqueak:QuackBehavior {
    override fun getQuack(): String {
        return "Squeak!"
    }
}