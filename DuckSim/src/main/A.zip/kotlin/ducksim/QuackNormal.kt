package ducksim

class QuackNormal:QuackBehavior {
    override fun getQuack(): String {
        return "Quack!"
    }
}