package ducksim

class QuackNoWay:QuackBehavior {
    override fun getQuack(): String {
        return ""
    }
}