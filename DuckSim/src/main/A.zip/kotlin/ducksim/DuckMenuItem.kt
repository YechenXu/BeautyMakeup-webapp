package ducksim

interface DuckMenuItem: () -> Unit
